# Projekt Fashion

This is a website we created for a customer who is starting out in the fashion industry as a stylist and personal shopper.

The repository includes:
1. Projektplan
2. HTML codes
3. CSS styles we used
